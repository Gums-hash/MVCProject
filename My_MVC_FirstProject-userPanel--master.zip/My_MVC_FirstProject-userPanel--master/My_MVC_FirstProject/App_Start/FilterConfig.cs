﻿using System.Web;
using System.Web.Mvc;

namespace My_MVC_FirstProject
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new HandleErrorAttribute());
        }
    }
}
