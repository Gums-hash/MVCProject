﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using My_MVC_FirstProject.Models;
using System.Data;
using System.Configuration;


namespace My_MVC_FirstProject.Controllers
{


    public class UserController : Controller
    {
        DbContext db = new DbContext();

        // GET: User
        public ActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public ActionResult Login(string email)
        {
            var row = db.GetUsers().Where(model => model.Emailid == email).FirstOrDefault();
            return View(row);
        }

        [HttpPost]
        public ActionResult Login(UserModel um)
        {
            var data = db.GetUsers().Where(model => model.Emailid == um.Emailid && model.Password == um.Password).FirstOrDefault();

            if(data != null)
            {
                Session["uid"] = um.Emailid;
                return RedirectToAction("Welcome");
            }
            else
            {
                ViewBag.Showmsg = "Invalid ID or Password !!";
                ModelState.Clear();
            }
            return View();
        }

        public ActionResult welcome()
        {
            var row = db.GetbyId(Session["uid"].ToString());
            return View(row);
        }

        [HttpGet]
        public ActionResult Create()
        {
            return View();

        }

        [HttpPost]
        public ActionResult Create(UserModel um)
        {
            db.Add(um);
            return RedirectToAction("Login");

        }

        [HttpGet]
        public ActionResult Edit(int id)
        {
            var data = db.GetUsers().Where(x => x.ID == id).FirstOrDefault();
            return View(data);
        }
        [HttpPost]
        public ActionResult Edit(UserModel um)
        {
            db.Update(um);
            return RedirectToAction("Welcome");
        }



    }
}